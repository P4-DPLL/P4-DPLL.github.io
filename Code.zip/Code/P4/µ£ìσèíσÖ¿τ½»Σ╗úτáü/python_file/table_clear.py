bfrt.control.pipe.Ingress.conflict_table_0.clear()

bfrt.control.pipe.Ingress.unit_table_0_0.clear()
bfrt.control.pipe.Ingress.unit_table_0_1.clear()
bfrt.control.pipe.Ingress.unit_table_0_2.clear()

bfrt.control.pipe.Ingress.conflict_table_1.clear()

bfrt.control.pipe.Ingress.unit_table_1_0.clear()
bfrt.control.pipe.Ingress.unit_table_1_1.clear()
bfrt.control.pipe.Ingress.unit_table_1_2.clear()

bfrt.control.pipe.Ingress.conflict_table_2.clear()

bfrt.control.pipe.Ingress.unit_table_2_0.clear()
bfrt.control.pipe.Ingress.unit_table_2_1.clear()
bfrt.control.pipe.Ingress.unit_table_2_2.clear()

bfrt.control.pipe.Ingress.register_conflict_table_segment_index.clear()
bfrt.control.pipe.Ingress.register_conflict_table_position_index.clear()

bfrt.control.pipe.Ingress.register_variable_record.clear()
bfrt.control.pipe.Ingress.register_layer_record.clear()
bfrt.control.pipe.Ingress.register_value_record.clear()

bfrt.control.pipe.Ingress.register_conflict_table_value_0.clear()
bfrt.control.pipe.Ingress.register_conflict_table_value_1.clear()
bfrt.control.pipe.Ingress.register_conflict_table_value_2.clear()
bfrt.control.pipe.Ingress.register_conflict_table_value_3.clear()
bfrt.control.pipe.Ingress.register_conflict_table_value_4.clear()
bfrt.control.pipe.Ingress.register_conflict_table_value_5.clear()
bfrt.control.pipe.Ingress.register_conflict_table_value_6.clear()
bfrt.control.pipe.Ingress.register_conflict_table_value_7.clear()

bfrt.control.pipe.Ingress.register_conflict_table_assigned_0.clear()
bfrt.control.pipe.Ingress.register_conflict_table_assigned_1.clear()
bfrt.control.pipe.Ingress.register_conflict_table_assigned_2.clear()
bfrt.control.pipe.Ingress.register_conflict_table_assigned_3.clear()
bfrt.control.pipe.Ingress.register_conflict_table_assigned_4.clear()
bfrt.control.pipe.Ingress.register_conflict_table_assigned_5.clear()
bfrt.control.pipe.Ingress.register_conflict_table_assigned_6.clear()
bfrt.control.pipe.Ingress.register_conflict_table_assigned_7.clear()

