#!/bin/bash

echo "build p4 file"

./../p4_build.sh $1
