#!/bin/bash

./../run_switchd.sh -p $1
