#!/bin/bash

#./../run_bfshell.sh -b ~/bf-sde-9.2.0/HZP/table_clear_and_write.py –i
./../run_bfshell.sh -b ~/bf-sde-9.2.0/HZP/setup.py –i