p4 = bfrt.test
p4.pipe.Ingress.conflict_table_1.clear()
p4.pipe.Ingress.conflict_table_2.clear()
p4.pipe.Ingress.conflict_table_3.clear()
p4.pipe.Ingress.conflict_table_4.clear()
p4.pipe.Ingress.conflict_table_5.clear()
p4.pipe.Ingress.conflict_table_6.clear()
p4.pipe.Ingress.conflict_table_7.clear()
p4.pipe.Ingress.unit_clause_table_1.clear()
p4.pipe.Ingress.unit_clause_table_2.clear()
p4.pipe.Ingress.unit_clause_table_3.clear()
p4.pipe.Ingress.unit_clause_table_4.clear()
p4.pipe.Ingress.unit_clause_table_5.clear()
p4.pipe.Ingress.unit_clause_table_6.clear()
p4.pipe.Ingress.unit_clause_table_7.clear()

#add_position
